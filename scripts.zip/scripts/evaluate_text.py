#!/usr/bin/env python3
import os, sys, json, torch, torch.nn.functional as F
from transformers import AutoTokenizer, AutoModelForSequenceClassification
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
def load_model(best_dir):
    tok = AutoTokenizer.from_pretrained(best_dir, use_fast=True)
    mdl = AutoModelForSequenceClassification.from_pretrained(best_dir)
    mdl.to(DEVICE); mdl.eval(); return tok, mdl
def main():
    if len(sys.argv) < 3:
        print("Usage: python scripts/evaluate_text.py <checkpoint_dir> \"<text>\""); sys.exit(1)
    ckpt, text = sys.argv[1], sys.argv[2]
    tok, mdl = load_model(ckpt)
    enc = tok([text], padding=True, truncation=True, max_length=256, return_tensors="pt")
    enc = {k:v.to(DEVICE) for k,v in enc.items()}
    with torch.no_grad(): logits = mdl(**enc).logits
    p_fake = float(F.softmax(logits, dim=-1)[:,1].detach().cpu().numpy()[0])
    print(json.dumps({"text": text, "p_fake": p_fake}, indent=2))
if __name__ == "__main__": main()
