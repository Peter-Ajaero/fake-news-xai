#!/usr/bin/env python3
import os, json, sys
from pathlib import Path
def main():
    root = Path(__file__).resolve().parents[1]
    ok = True
    must = [
        root/'streamlit_app.py',
        root/'requirements.txt',
        root/'artifacts_final'/'meta.json',
        root/'artifacts_final'/'plots',
        root/'artifacts_final'/'metrics',
        root/'figures',
    ]
    for p in must:
        if not p.exists():
            print(f"Missing: {p}"); ok = False
    print(json.dumps({"package_ok": ok, "root": str(root)}))
    sys.exit(0 if ok else 1)
if __name__ == "__main__": main()
