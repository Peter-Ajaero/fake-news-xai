#!/usr/bin/env python3
import os, sys, re, json, numpy as np, torch, torch.nn.functional as F
from transformers import AutoTokenizer, AutoModelForSequenceClassification
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
_word_re = re.compile(r"\w+|[^\w\s]", flags=re.UNICODE)
def word_tokenize(t): return _word_re.findall(t or "")
def load_model(best_dir):
    tok = AutoTokenizer.from_pretrained(best_dir, use_fast=True)
    mdl = AutoModelForSequenceClassification.from_pretrained(best_dir)
    mdl.to(DEVICE); mdl.eval(); return tok, mdl
def p_fake(tok, mdl, texts):
    enc = tok(texts, padding=True, truncation=True, max_length=256, return_tensors="pt")
    enc = {k:v.to(DEVICE) for k,v in enc.items()}
    with torch.no_grad(): logits = mdl(**enc).logits
    return F.softmax(logits, dim=-1)[:,1].detach().cpu().numpy()
def main():
    if len(sys.argv) < 3:
        print("Usage: python scripts/occlusion_explain.py <checkpoint_dir> \\"<text>\\""); sys.exit(1)
    ckpt, text = sys.argv[1], sys.argv[2]
    tok, mdl = load_model(ckpt)
    toks = word_tokenize(text); base = float(p_fake(tok, mdl, [" ".join(toks)])[0])
    scores = []
    for i in range(len(toks)):
        tmp = toks.copy(); tmp[i] = tok.mask_token or "[MASK]"
        p = float(p_fake(tok, mdl, [" ".join(tmp)])[0]); scores.append(base - p)
    out = {"text": text, "base_p_fake": base, "tokens": toks, "contrib": scores}
    print(json.dumps(out, indent=2))
if __name__ == "__main__": main()
