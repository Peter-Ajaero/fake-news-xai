#!/usr/bin/env python3
import os, sys, csv, torch, torch.nn.functional as F
from transformers import AutoTokenizer, AutoModelForSequenceClassification
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
def load_model(best_dir):
    tok = AutoTokenizer.from_pretrained(best_dir, use_fast=True)
    mdl = AutoModelForSequenceClassification.from_pretrained(best_dir)
    mdl.to(DEVICE); mdl.eval(); return tok, mdl
def predict_texts(tok, mdl, texts):
    enc = tok(texts, padding=True, truncation=True, max_length=256, return_tensors="pt")
    enc = {k:v.to(DEVICE) for k,v in enc.items()}
    with torch.no_grad(): logits = mdl(**enc).logits
    return F.softmax(logits, dim=-1)[:,1].detach().cpu().numpy().tolist()
def main():
    if len(sys.argv) < 4:
        print("Usage: python scripts/batch_predict.py <checkpoint_dir> <input.txt> <output.csv>"); sys.exit(1)
    ckpt, inp, outp = sys.argv[1], sys.argv[2], sys.argv[3]
    tok, mdl = load_model(ckpt)
    texts = [line.strip() for line in open(inp, "r", encoding="utf-8") if line.strip()]
    probs = predict_texts(tok, mdl, texts)
    with open(outp, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f); w.writerow(["text","p_fake"])
        for t, p in zip(texts, probs): w.writerow([t, f"{p:.6f}"])
    print(f"Wrote {len(texts)} rows to {outp}")
if __name__ == "__main__": main()
