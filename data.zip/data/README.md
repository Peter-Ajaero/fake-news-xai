# Data: LIAR

The LIAR dataset is **not** redistributed in this submission.
Obtain it from an approved source and keep TSVs privately.

Label mapping used:
- FAKE: pants-fire, false, barely-true
- REAL: half-true, mostly-true, true
